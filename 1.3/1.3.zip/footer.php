<?php
/*
|-----------------------------------|
|	PadsanSystem					|
|-----------------------------------|
|	Uploadcenter Version			|
|-----------------------------------|
|	Web   : www.PadsanSystem.com	|
|	Email : Info@PadsanSystem.com	|
|	Tel   : +98 - 26 325 45 700		|
|	Fax   : +98 - 26 325 45 701		|
|-----------------------------------|
*/
?>
<div id="footer">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<p class="text-muted text-center"><small><br>Copyright &copy; 2011-2014 Uploadchi.com. All Rights Reserved</small></p>
			</div>
		</div>
	</div>
</div>
<script src="<?php echo JAVASCRIPTS."jquery.js"; ?>"></script>
<script src="<?php echo JAVASCRIPTS."jquery-ui.min.js"; ?>"></script>
<script src="<?php echo JAVASCRIPTS."bootstrap.min.js"; ?>"></script>
<script src="<?php echo JAVASCRIPTS."jasny-bootstrap.min.js"; ?>"></script>
<script src="<?php echo JAVASCRIPTS."tab.js"; ?>"></script>
<script src="<?php echo JAVASCRIPTS."modal.js"; ?>"></script>
<script src="<?php echo JAVASCRIPTS."tooltip.js"; ?>"></script>
<script src="<?php echo JAVASCRIPTS."fileinput.js"; ?>"></script>
<script src="<?php echo JAVASCRIPTS."inputmask.js"; ?>"></script>
</body>
</html>