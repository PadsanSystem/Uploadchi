<html>
<head>
	<title>Uploadchi - Access Denied</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body style="cursor:default;">
	<table width="100%" height="100%">
		<tr>
			<td valign="center" align="center">
				<center><span style="font-family:tahoma; font-size:18pt; color:#999999; font-weight:bold;">Access Denied</span>
				<br>
				<span style="font-family:tahoma; font-size:10pt; color:#cccccc;">Design & Development By <a style="color:#cccccc; font-weight:bold; text-decoration:none;" onmouseover="this.style.color='#999999'" onmouseout="this.style.color='#cccccc'" href="http://www.padsansystem.com">PadsanSystem</a></span>
				</center> 
			</td>
		</tr>
	</table>
</body>
</html>